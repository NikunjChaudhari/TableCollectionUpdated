//
//  CollectionViewCell.swift
//  TableCollectionTask
//
//  Created by macos on 24/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgvw: UIImageView!
    
}
